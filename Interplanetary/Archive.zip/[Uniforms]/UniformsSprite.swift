//
//  UniformsSprite.swift
//  RebuildEarth
//
//  Created by Nick Raptis on 2/12/23.
//
//  Verified on 11/9/2024 by Nick Raptis
//

import Foundation

typealias UniformsSpriteVertex = UniformsShapeVertex
typealias UniformsSpriteFragment = UniformsShapeFragment
