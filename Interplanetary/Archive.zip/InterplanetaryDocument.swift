//
//  InterplanetaryDocument.swift
//  Interplanetary
//
//  Created by Nicholas Raptis on 5/2/25.
//

import Foundation

class InterplanetaryDocument {
    
    weak var interplanetaryScene: InterplanetaryScene?
    
    
    @MainActor func applicationWillResignActive(interplanetaryViewModel: InterplanetaryViewModel) {
        
    }
    
    @MainActor func applicationDidBecomeActive() {
        
    }
    
    @MainActor func handleWakeUpComplete_PartA(interplanetaryEngine: InterplanetaryEngine) {
        
    }
    
    @MainActor func handleWakeUpComplete_PartB(interplanetaryEngine: InterplanetaryEngine) {
        
    }
    
    @MainActor func handleExit() {
        
    }
    
}
