//
//  main.swift
//  Interplanetary
//
//  Created by Nicholas Raptis on 5/1/25.
//

import Cocoa

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
